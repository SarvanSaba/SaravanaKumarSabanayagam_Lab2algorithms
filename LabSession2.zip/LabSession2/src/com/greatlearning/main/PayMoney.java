package com.greatlearning.main;

import java.util.Scanner;

public class PayMoney {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner (System.in);
		
		System.out.println ("Enter the size of transaction array :");
		
		int size = sc.nextInt();
		
		int[] transactionarray = new int[size];
		
		System.out.println ("Enter the values of array :");
		
		for (int i=0;i<size;i++) {
			
			transactionarray[i] = sc.nextInt();

	}
		
		System.out.println ("Enter the total number of targets that needs to be achieved :");
		
		int numberofTarget = sc.nextInt();
		
		while (numberofTarget--!=0) {
			
			int fl = 0;
			
			System.out.println ("Enter the value of target :");
			
			int target = sc.nextInt();
			
			int transaction = 0;
			
			for (int i=0;i<size;i++) {
				
				transaction += transactionarray[i];
				
				if (transaction >= target) {
					
					System.out.println ("Target achieved after "+(i+1)+" transactions");
					
					fl = 1;
					
					System.out.println ();
					
					break;
					
				}		
				
			}
			
			if (fl == 0) {
				
				System.out.println ("Given target is not achieved");
				
			}
			
		}

}
	
}
