package com.greatlearning.main;

import java.util.Scanner;

public class CurrencyDenominations {

	public static void main(String[] args) {
				
		Scanner sc = new Scanner (System.in);
		
		System.out.println ("Enter the size of currency denominations :");
		
		int size = sc.nextInt();
		
		System.out.println ("Enter the currency denominations value :");
		
		int[] notes = new int[size];
		
		for (int i=0;i<size;i++) {
			
			notes[i] = sc.nextInt();
			
		}
		
		System.out.println ("Enter the amount you want to pay :");
		
		int amount = sc.nextInt();		
		
		MergeSort.sort (notes, 0, notes.length-1);
		
		int[] notecounter = new int[notes.length];
		
		try {
			
			for (int i=0;i<notes.length;i++) {
				
				if (amount >= notes[i]) {
					
					notecounter[i] = amount / notes[i];
					
					amount = amount - (notecounter[i] * notes[i]);
					
				}
				
			}
			
			if (amount > 0) {
				
				System.out.println ("Exact amount cannot be given with the highest denomination");
				
			}
			
			else {
				
				System.out.println ("Your payment approach in order to give minimum number of notes will be");
				
				for (int i=0;i<notes.length;i++) {
					
					if (notecounter[i] != 0) {
						
						System.out.println (notes[i] + ":" + notecounter[i]);
						
					}
					
				}
				
			}
						
		}
		
		catch (ArithmeticException e) {
			
			System.out.println (e + " Notes of denomination 0 is invalid");
		}
		
	}
	

public class MergeSort {
	
	static void merge (int arr[], int left, int mid, int right) {
		
		int a = mid-left+1;
		int b = right-mid;
		
		int leftarr[] = new int[a];
		int rightarr[] = new int[b];
		
		for (int i=0;i<a;++i) {
			
			leftarr[i] = arr[left+i];
			
		}
		
		for (int j=0;j<b;++j) {
			
			rightarr[j] = arr[mid+1+j];
			
		}
		
		int i = 0;
		
		int j = 0;
		
		int k = left;
		
		while (i<a && j<b) {
			
			if (leftarr[i] >= rightarr[j]) {
				
				arr[k] = leftarr[i];
				
				i++;
				
			}
			
			else {
				
				arr[k] = rightarr[j];
				
				j++;
				
			}
			
			k++;
			
		}
		
		while (i<a) {
			
			arr[k] = leftarr[i];
			i++;
		    k++;
			
		}
		
		while (i<b) {
			
			arr[k] = rightarr[j];
			j++;
			k++;
			
		}
		
	}
	
	public static void sort (int[] notes, int left, int right) {
		
		if (left < right) {
			
			int mid = (left + right) / 2;
			
			sort (notes, left, mid);
			
			sort (notes, mid+1, right);
			
			merge (notes, left, mid, right);
			
		}		
		
	}
		
	}	
	
}




